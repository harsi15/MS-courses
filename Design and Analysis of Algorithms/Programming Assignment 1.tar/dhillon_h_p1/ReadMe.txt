Java
javac MaxProfitCards.java
java MaxProfitCards market_price.txt price_list.txt