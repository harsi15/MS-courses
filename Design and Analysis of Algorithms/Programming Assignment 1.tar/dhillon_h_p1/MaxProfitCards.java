import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class baseBallCard{
    // Creating a class of BaseBallCard to store the parameters mentioned below.
    String cardName;           // To store the name of the baseball card
    int cardPrice;             // To store the price of the card at which we are buying it from Gertrude
    int marketPrice;           // To store the market price of the card (To calculate the profit)

    baseBallCard(String cardName,int cardPrice, int marketPrice){           //Constructor to initialise the values
        this.cardName = cardName;
        this.cardPrice = cardPrice;
        this.marketPrice = marketPrice;
    }
}
public class MaxProfitCards {
    public static void main(String[] args) throws IOException {
        String marketPriceList = args[0];               //Taking the input name of the market file from the arguments
        String buyingPriceList = args[1];               //Taking the input name of the price file from the arguments
        int totalBuyCards=0;

        int maxWeight = 0;
        //File marketPricefile = new File("C:\\Users\\Personal\\IdeaProjects\\DAAHw01\\src\\m_30.txt");
        File marketPricefile = new File(marketPriceList);
        Scanner sc = new Scanner(marketPricefile);              //Using Scanner to read the file
        List<baseBallCard> buyValueCards = new ArrayList<>();
        List<baseBallCard> marketValueCards = new ArrayList<>();
        List<List<baseBallCard>> totalInputList = new ArrayList<>();

        StringBuilder marketPriceString = new StringBuilder();
        StringBuilder buyingPriceString = new StringBuilder();

        while(sc.hasNextLine()){                                //Condition to check whether we have next element present in the file, it will return true if we have next element present in the file
            marketPriceString.append(sc.nextLine()).append(";");
        }
        //System.out.println("Market Price list file contents are:\n"+marketPriceString);    //printing the contents of the file line by line.
        //File buyingPricefile = new File("C:\\Users\\Personal\\IdeaProjects\\DAAHw01\\src\\p_30.txt");
        File buyingPricefile = new File(buyingPriceList);
        Scanner sc2 = new Scanner(buyingPricefile);
        while(sc2.hasNextLine()){                                // Condition to check whether we have next element present in the file
            buyingPriceString.append(sc2.nextLine()).append(";");       //Adding semi colon to seperate each line of the file
            if(sc2.hasNextInt()){
                buyingPriceString.append("#").append(sc2.nextLine()).append(";");       //Adding # to seperate multiple input present inside a input file
            }
        }
        //System.out.println("Buying Price list file contents are :\n"+buyingPriceString);    //printing the contents of the file line by line.

        String[] extractMarketPriceFields = marketPriceString.toString().split(";");        //Extracting the contents of the file
        int totalMarketCardsList = Integer.parseInt(extractMarketPriceFields[0].trim());

        for(int i = 1; i<=totalMarketCardsList; i++){
           String[] marketPricePartition = extractMarketPriceFields[i].split(" ");
           String cardName = marketPricePartition[0];
           int marketValue = Integer.parseInt(marketPricePartition[1]);
           marketValueCards.add(new baseBallCard(cardName,0,marketValue));              //Adding the market price list of the baseball cards to a marketValueCards List
        }

        String[] extractBuyingPriceFields = buyingPriceString.toString().split("#");        //Splitting the input files into multiple parts based on the number of inputs present in input file

        for(int i= 0;i<extractBuyingPriceFields.length;i++){
            String[] buyingPriceOuterPartition = extractBuyingPriceFields[i].split(";");    //Extracting the fields of each input present inside the input file
            buyValueCards = null;
            for(int j = 0;j<(buyingPriceOuterPartition.length);j++){
                if(buyValueCards == null){
                    buyValueCards = new ArrayList<>();
                    totalInputList.add(buyValueCards);
                }
                String[] buyingPriceInnerPartition = buyingPriceOuterPartition[j].split(" ");   //Extracting the card name and price
                String cardName = buyingPriceInnerPartition[0];                                 //Storing the name of the card
                int buyValue = Integer.parseInt(buyingPriceInnerPartition[1]);
                buyValueCards.add(new baseBallCard(cardName,buyValue,0));
            }
        }

        //To check the contents of both the list (Total list i.e the input file list and the market price list)
        /*for(List<baseBallCard> list : totalList){
            for(baseBallCard item : list) {
                System.out.println("Card Name: " + item.cardName + "Buying Value : " + item.cardPrice);
            }
        }
        for(int i = 0; i<totalMarketCards;i++){
            System.out.println("Card Name: "+marketValueCards.get(i).cardName +"Market Value : "+marketValueCards.get(i).marketPrice);
        }*/

            for(int i=0; i<totalInputList.size();i++){
                List<baseBallCard> listIterator = totalInputList.get(i);
                int totalCards = Integer.parseInt(listIterator.get(0).cardName);        //To fetch the total input cards
                maxWeight = listIterator.get(0).cardPrice;                              //To fetch the max price we can spend
                listIterator.remove(0);                                           //Removing the first element of the list as we have already read the values of it.
                profitCalculator(totalCards, totalMarketCardsList, maxWeight, listIterator,marketValueCards);
            }
    }

    public static void profitCalculator(int totalBuyCards,int totalMarketCards, int maxWeight, List<baseBallCard> buyValueCards, List<baseBallCard> marketValueCards) throws IOException {

        long beginTime = System.nanoTime();
        int bruteInt = 0;
        int profit = 0;
        int weight = 0;
        int maxProfit = 0;
        String outputFile = "output.txt";      //To print the values to a output file.
        FileWriter outputFileWriter = null;
        BufferedWriter bufferedWriter = null;
        PrintWriter printWriter = null;

        //Creating a Binary Matrix for Brute integer multiplication to cover all the combination for maximum profit
        int bruteSize = (int)Math.pow(2,totalBuyCards);
        String[] bruteArr = new String[bruteSize];
        for(int i = 0; i < bruteSize; i++){
            bruteArr[i] = Integer.toBinaryString(i);
            if(bruteArr[i].length()<totalBuyCards){
                int diff = totalBuyCards - bruteArr[i].length();
                for(int j = 0; j< diff;j++){
                    bruteArr[i] = 0+bruteArr[i];
                }
            }
            //System.out.println(bruteArr[i]);
        }


        //Inserting the market price of the card from 1 list to another so that we can compare both buying price and selling price in one list
        for(int i = 0;i<totalBuyCards;i++){
            for(int j=0;j<totalMarketCards;j++){
                if(buyValueCards.get(i).cardName.equalsIgnoreCase(marketValueCards.get(j).cardName)) {
                    buyValueCards.get(i).marketPrice = marketValueCards.get(j).marketPrice;
                    //System.out.println("Hello "+buyValueCards.get(i).marketPrice);
                }
            }
        }
        List<String> selectedCards = new ArrayList<>();             //ArrayList to store our final output of the selected Cards

        for(int i = 0; i<bruteSize;i++){
            weight =0;
            profit =0;
            ArrayList<String> tempSelectedCards = new ArrayList<>();    //Creating a temp ArrayList to store the values of the cards which are stored while comparing
            for(int j = 0;j<totalBuyCards;j++){
                bruteInt = bruteArr[i].charAt(j)-48;                //subtracting the bruteInt from the ASCII value to get output as binary
                weight = weight + (buyValueCards.get(j).cardPrice*bruteInt);
                if (weight <= maxWeight ) {                         //We will calculate profit only if the sum of the price of the cards are less than the maximum allowed price
                        profit = profit + (buyValueCards.get(j).marketPrice - buyValueCards.get(j).cardPrice)*bruteInt;
                        //System.out.println("Profit is: " + profit);
                        //System.out.println(buyValueCards.get(j).cardName);
                        //System.out.println("Buying price is " + weight);
                        if(bruteInt==1){
                            tempSelectedCards.add(buyValueCards.get(j).cardName);
                        }
                        //System.out.println(tempSelectedCards);
                }else{                                          //If the sum of the weight exceeds maxWeight then reset the weight and profit values to 0.
                    weight =0;
                    profit = 0;

                }
                //System.out.println(tempSelectedCards);
            }
            //System.out.println(totalBuyCards+" "+maxProfit+" "+" "+tempSelectedCards.size()+"\n");
            //System.out.println("SelectedCards are :"+tempSelectedCards);

            if(profit>maxProfit && weight<=maxWeight){          //Transfer the values of the tempSelected cards to our Final output of the Selected Cards.
                selectedCards = tempSelectedCards;
                maxProfit = profit;
            }
        }
        long endTime = System.nanoTime();                          //To calculate the time required to do the computation.
        double totalTime = (endTime - beginTime);
        double totalTimeInSeconds = totalTime / 1000000000;      //Converting to Seconds from NanoSeconds
        //System.out.println(totalTimeInSeconds);
        try {
            outputFileWriter = new FileWriter(outputFile, true);    //Using FileWriter, bufferedWriter and printWriter to write into output file and using Append parameter as True.
            bufferedWriter = new BufferedWriter(outputFileWriter);
            printWriter = new PrintWriter(bufferedWriter);
            printWriter.println(totalBuyCards+" "+maxProfit+" "+selectedCards.size()+" "+totalTimeInSeconds);   //println function of the printWriter will print the output on new line
            for(int i=0;i<selectedCards.size();i++){
                printWriter.println(selectedCards.get(i));          // To print each element of the Arraylist 1 by 1.
            }
            printWriter.close();
            bufferedWriter.close();
            outputFileWriter.close();                                //Closing the file
        } catch (IOException io){

        }
        //To print the output on the console
        System.out.println(totalBuyCards+" "+maxProfit+" "+selectedCards.size()+" "+totalTimeInSeconds);
        for(int i=0;i<selectedCards.size();i++){
            System.out.println(selectedCards.get(i));          // To print each element of the Arraylist 1 by 1.
        }
    }
}
