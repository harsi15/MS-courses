Language Java

javac backtrack.java
java backtrack program5_n4_knapsack01.txt