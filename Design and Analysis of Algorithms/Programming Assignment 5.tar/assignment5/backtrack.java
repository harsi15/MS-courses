import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

//Creating a class to use as a custom object to store different parameters
class Item {
    int profit;
    int weight;

    float profitRatio;

    //Creating a getter to fetch the ratio so that we can sort it on the basis of the ratio
    public float getProfitRatio() {
        return profitRatio;
    }

    String itemIndex;

    public String getItemIndex() {
        return itemIndex;
    }

    Item(String index, int profitValue, int weightValue){
        this.profit = profitValue;
        this.weight = weightValue;
        this.itemIndex = index;
    }
}

//BackTrack Class
public class backtrack {

    static int maxProfit;                                                               //To keep track of maximum Profit
    static int[] include;                                                               //To temporarily store the included items
    static int[] bestSet;                                                               //This will have our required output items
    static int totalItems;                                                              //To store total items
    static int totalWeight;                                                             //To store total weight
    static StringBuilder traversalValues = new StringBuilder();                         //Using to store the output for traversal entries
    static int num =0;                                                                  //Used as number counter while printing in entries file

    //Used to calculate the upperbound of items
    static double KWF2(int i, int profit, int weightUsed, List<Item> itemList) {
        double bound = profit;
        double weightRatio;                                                         //To store the fraction of item

        while (weightUsed < totalWeight && i <= totalItems) {
            if (weightUsed + itemList.get(i - 1).weight <= totalWeight) {
                bound = bound + itemList.get(i - 1).profit;
                weightUsed = weightUsed + itemList.get(i - 1).weight;
            } else {
                weightRatio = (float) (totalWeight - weightUsed) / (float) itemList.get(i - 1).weight;                  //Calculating the fraction of remaining weight
                weightUsed = totalWeight;
                bound = bound + itemList.get(i - 1).profit * weightRatio;
            }
            i++;
        }

        return bound;
    }

    //We will be checking promising condition over here
    static boolean promising(int i, int profit, int weight, List<Item> itemList) {
        num++;                                                                                      //Incrementing the counter

        if (weight >= totalWeight) {
            //Storing the output of entries file in the required format
            traversalValues.append(num).append(" ").append(profit).append(" ").append(weight).append(" ").append(0).append("\n");
            return false;
        }

        //Calling the upper bound function to calculate the upper bound
        float upperBound = (float) KWF2(i + 1, profit, weight, itemList);

        if(upperBound > 0){
            //Storing the output of entries file in the required format
            traversalValues.append(num).append(" ").append(profit).append(" ").append(weight).append(" ").append(String.format("%.6f", upperBound)).append("\n");
        }else{
            //Storing the upperbound as 0 of entries file in the required format
            traversalValues.append(num).append(" ").append(profit).append(" ").append(weight).append(" ").append(0).append("\n");
        }
        return (upperBound > maxProfit);
    }

    //Main function which will be recursively called to find the optimal solution
    static void knapsackBacktracking(int i, int profit, int weight, List<Item> itemList) {

        //Condition to check if the weight is less than the capacity of knapsack and profit is less than the max profit
        if (weight <= totalWeight && profit > maxProfit) {
            maxProfit = profit;
            for(int j = 1; j < totalItems; j++) {
                bestSet[j] = include[j];
            }
        }

        //Checking if the item is promising or not and calling function recursively accordingly
        if (promising(i, profit, weight, itemList)) {
            include[i + 1] = 1;
            knapsackBacktracking(i + 1, profit + itemList.get(i).profit, weight + itemList.get(i).weight, itemList);
            include[i + 1] = 0;
            knapsackBacktracking(i + 1, profit, weight, itemList);
        }
    }


    public static void main(String[] args) throws FileNotFoundException {

        //Initializing the filename variable to null;
        String filename ="";

        //Checking if we have valid number of arguments passed or not, if not then a custom error message will be displayed in the console
        if(args.length!=1){
            System.out.println("Invalid number of Arguments: Please provide a single filename from where the input has to be read");
            System.exit(1);
        }

        //fetching the filename from the argument
        filename = args[0];

        //Initializations
        File readFile = new File(filename);                                             //Storing filename
        Scanner sc = new Scanner(readFile);                                             //Initializing scanner object
        StringBuilder inputListAndWeight = new StringBuilder();                         //To store the number of items and knapsack capacity
        StringBuilder inputList = new StringBuilder();                                  //To Fetch the input list from the file
        StringBuilder outputList = new StringBuilder();                                 //To store the output list which is selected

        //Iterating through the file to fetch the input
        while(sc.hasNext()){

            //To fetch the number of items and weight we will append the inputListAndWeight String with # so that it becomes easy to split the String
            if(sc.hasNextInt()){
                inputListAndWeight.append(sc.nextInt()).append("#");
            }
            else{
                //To fetch the items we will append the inputList String with # so that it becomes easy to split each item
                inputList.append(sc.nextLine()).append("#");
            }

        }

        //Using split function to get the required values and storing it in the variables
        String[] numberAndWeight = inputListAndWeight.toString().split("#");
        totalItems = Integer.parseInt(numberAndWeight[0]);
        totalWeight = Integer.parseInt(numberAndWeight[1]);
        //System.out.println(totalItems);
        //System.out.println(totalWeight);

        //Using split function to split each item and storing them in a list
        String[] inputItemList = inputList.toString().split("#");
        List<Item> itemList = new ArrayList<>();
        for (int i = 1; i<=totalItems;i++){
            //System.out.println(itemList[i]);
            String[] itemSplit = inputItemList[i].split(" ");
            String itemName = itemSplit[0];
            int itemProfit = Integer.parseInt(itemSplit[1]);
            int itemWeight = Integer.parseInt(itemSplit[2]);
            Item item = new Item(itemName,itemProfit,itemWeight);
            itemList.add(item);
        }

        //To check the items of the list
        /*for(int i = 0; i< totalItems; i++){
            System.out.println(itemList.get(i).itemIndex+" "+itemList.get(i).profit+" "+itemList.get(i).weight);
        }*/

        //Calculating the Profit/Weight ratio and storing in the list
        for(int i =0; i<itemList.size();i++){
            itemList.get(i).profitRatio = (float) itemList.get(i).profit / itemList.get(i).weight;
        }

        //Sorting the profit/Weight ratio in non-ascending order to get the highest ratio at the beginning of the list
        itemList.sort(Comparator.comparingDouble(Item::getProfitRatio).reversed());

        //Initializing the Arrays to a totalItems + 1 size
        bestSet = new int[totalItems+1];
        include = new int[totalItems+1];

        //Calling the knapsackBacktracking function
        knapsackBacktracking(0, 0, 0, itemList);

        //To Store the weight and profit values
        int tempWeight = 0;
        int tempProfit = 0;

        //Initializing a list to store the selected items
        List<Item> selectedList = new ArrayList<>();

        //Iterating through the loop to put the selected items in selectedList
        for (int k = 0; k < totalItems; k++) {
            if (bestSet[k]==1) {
                Item item2 = new Item(itemList.get(k-1).itemIndex,itemList.get(k-1).profit,itemList.get(k-1).weight);
                selectedList.add(item2);
                tempWeight = tempWeight + itemList.get(k-1).weight;
                tempProfit = tempProfit +itemList.get(k-1).profit;
                //System.out.println(itemList.get(k).itemIndex+" "+itemList.get(k).profit+" "+itemList.get(k).weight);
            }
        }


        //Sorting the list in ascending order of the itemIndex
        selectedList.sort(Comparator.comparing(Item::getItemIndex));

        //Storing the output in the required format
        outputList.append(selectedList.size()).append(" ").append(tempProfit).append(" ").append(tempWeight).append("\n");
        for(int i=0;i<selectedList.size();i++){
            outputList.append(selectedList.get(i).itemIndex).append(" ").append(selectedList.get(i).profit).append(" ").append(selectedList.get(i).weight).append("\n");
        }

        //To check the traversal entries values
        //System.out.println(traversalValues);

        //Using FileWriter to write in a file
        try{
            FileWriter fileWriter = new FileWriter("output3.txt");
            FileWriter fileWriter1 = new FileWriter("entries3.txt");
            fileWriter1.write(traversalValues.toString());
            fileWriter.write(outputList.toString());
            fileWriter.close();
            fileWriter1.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
