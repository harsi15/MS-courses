import java.util.Random;
import java.lang.Math;

public class Dhillon_h_pa2_strassen {

    //Creating a function to accept the matrix input at runtime
    public int[][] accept_input(int size){
        int maxInteger =1024;                   //Max integer possible
        int maxRandomInteger = (int)Math.floor(Math.sqrt(maxInteger/size));             //Generating the max random integer using the formula
        Random rand = new Random();                                         //Random function to generate random int
        int[][] inputMatrix = new int[size][size];
        for (int i = 0; i < size ; i++){
            for(int j = 0 ; j < size ; j++){
                inputMatrix[i][j] = rand.nextInt(maxRandomInteger);         //Generating random integers keeping the max random integer value as bound
            }
        }
        return inputMatrix;
    }

    //Standard Matrix Multiplication O(n^3)
    public int[][] matrix_multiplication(int size,int[][] matrix_A, int[][] matrix_B){
        int[][] matrix_result = new int[size][size];                  //Declaring int Array matrix_result  to store result
        for(int i = 0; i < size; i++){
            for(int j = 0; j < size; j++){
                for(int k = 0; k < size; k++) {
                    matrix_result[i][j] = matrix_result[i][j] + matrix_A[i][k] * matrix_B[k][j];
                }
            }
        }
        return matrix_result;
    }

    //Function to divide the matrix into half of the size (column and row)
    public int[][] matrix_partition(int[][] matrix,int part, int start, int end){
        int[][] partition = new int[part][part];
        int d = end;                                                //temp variable to store the end value
        for(int i = 0 ; i < part ; i++){
            end = d;                                                //reinitialising end for each loop
            for(int j = 0 ; j < part ; j++){
                partition[i][j] = matrix[start][end];               //partition will have our n/2 * n/2 matrix
                end++;                                              //Incrementing end inside the loop
            }
            start++;
        }
        return partition;
    }

    //Function to join the partitioned matrix to form a resultant matrix
    public void matrix_join(int[][] matrix_union, int[][] matrix, int start, int end){
        int size = matrix.length;
        int d = end;                                                    //temp variable to store the end value
        for(int i = 0 ; i < size ; i++){
            end = d;                                                    //reinitialising for each loop
            for(int j = 0 ; j < size ; j++){
                matrix_union[start][end] = matrix[i][j];                //matrix_union is our final matrix
                end++;                                                  //Incrementing inside the loop
            }
            start++;
        }
    }

    //Function to add two matrices
    public int[][] matrix_addition(int[][] matrix_A, int[][] matrix_B){
        int size = matrix_A.length;
        int[][] matrix_C = new int[size][size];
        for(int i = 0; i < size; i++){
            for(int j = 0; j < size; j++){
                matrix_C[i][j] = matrix_A[i][j] + matrix_B[i][j];
            }
        }
        return matrix_C;
    }

    //Function to subtract to matrices
    public int[][] matrix_subtraction(int[][] matrix_A, int[][] matrix_B){
        int size = matrix_A.length;
        int[][] matrix_C = new int[size][size];
        for(int i = 0; i < size; i++){
            for(int j = 0; j < size; j++){
                matrix_C[i][j] = matrix_A[i][j] - matrix_B[i][j];
            }
        }
        return matrix_C;
    }


    public int[][] strassen_multiplication(int[][] matrix_A, int[][] matrix_B){

        int size = matrix_A.length;                            // Extracting the size of the matrix
        int part = matrix_A.length/2;                          // Initializing a variable half the size so that we can use it to create n/2 x n/2 matrix

        int[][] matrix_strassen_result = new int[size][size];   //Initializing resultant matrix

        if(size == 1){
            //Base case condition to return the value when we are not able to divide further
            matrix_strassen_result[0][0] = matrix_A[0][0] * matrix_B[0][0];
        }
        else {
            //Making 4 parts of Matrix A as follows
            int[][] matrix_A11 = matrix_partition(matrix_A, part, 0, 0);            //Upper left corner matrix
            int[][] matrix_A12 = matrix_partition(matrix_A, part, 0, part);              //Upper right corner matrix
            int[][] matrix_A21 = matrix_partition(matrix_A, part, part, 0);               //lower left corner matrix
            int[][] matrix_A22 = matrix_partition(matrix_A, part, part, part);                 //lower right corner matrix

            //Making 4 parts of Matrix B as follows
            int[][] matrix_B11 = matrix_partition(matrix_B, part, 0, 0);            //Upper left corner matrix
            int[][] matrix_B12 = matrix_partition(matrix_B, part, 0, part);              //Upper right corner matrix
            int[][] matrix_B21 = matrix_partition(matrix_B, part, part, 0);               //lower left corner matrix
            int[][] matrix_B22 = matrix_partition(matrix_B, part, part, part);                 //lower right corner matrix

            //M1 = (A11 + A22)(B11 + B22)
            int[][] addition_1 = matrix_addition(matrix_A11, matrix_A22);
            int[][] addition_2 = matrix_addition(matrix_B11, matrix_B22);
            int[][] matrix_M1 = strassen_multiplication(addition_1, addition_2);            //Recursive function call

            //M2 = (A21 + A22) * B11
            int[][] addition_3 = matrix_addition(matrix_A21, matrix_A22);
            int[][] matrix_M2 = strassen_multiplication(addition_3, matrix_B11);            //Recursive function call

            //M3 = A11 * (B12 - B22)
            int[][] subtraction_1 = matrix_subtraction(matrix_B12, matrix_B22);
            int[][] matrix_M3 = strassen_multiplication(matrix_A11, subtraction_1);         //Recursive function call

            //M4 = A22 * (B21 - B11)
            int[][] subtraction_2 = matrix_subtraction(matrix_B21, matrix_B11);
            int[][] matrix_M4 = strassen_multiplication(matrix_A22, subtraction_2);         //Recursive function call

            //M5 = (A11 + A12) * B22
            int[][] addition_4 = matrix_addition(matrix_A11, matrix_A12);
            int[][] matrix_M5 = strassen_multiplication(addition_4, matrix_B22);            //Recursive function call

            //M6 = (A21 - A11) * (B11 + B12)
            int[][] subtraction_3 = matrix_subtraction(matrix_A21, matrix_A11);
            int[][] addition_5 = matrix_addition( matrix_B11, matrix_B12);
            int[][] matrix_M6 = strassen_multiplication( subtraction_3, addition_5);        //Recursive function call

            //M7 = (A12 - A22) * (B21 + B22)
            int[][] subtraction_4 = matrix_subtraction(matrix_A12, matrix_A22);
            int[][] addition_6 = matrix_addition( matrix_B21, matrix_B22);
            int[][] matrix_M7 = strassen_multiplication( subtraction_4, addition_6);        //Recursive function call

            //C11 = M1 + M4 - M5 + M7
            int[][] addition_7 = matrix_addition( matrix_M1, matrix_M4);
            int[][] subtraction_5 = matrix_subtraction( addition_7, matrix_M5);
            int[][] matrix_C11 = matrix_addition( subtraction_5, matrix_M7);

            //C12 = M3 + M5
            int[][] matrix_C12 = matrix_addition( matrix_M3, matrix_M5);

            //C21 = M2 + M4
            int[][] matrix_C21 = matrix_addition(matrix_M2, matrix_M4);

            //C22 = M1 - M2 + M3 + M6
            int[][] subtraction_6 = matrix_subtraction(matrix_M1, matrix_M2);
            int[][] addition_9 = matrix_addition(subtraction_6, matrix_M3);
            int[][] matrix_C22 = matrix_addition( addition_9, matrix_M6);

            //Joining all the partitioned matrices to create our resultant matrix
            matrix_join(matrix_strassen_result, matrix_C11, 0 , 0);
            matrix_join(matrix_strassen_result, matrix_C12, 0 , size/2);
            matrix_join(matrix_strassen_result, matrix_C21, size/2, 0);
            matrix_join(matrix_strassen_result, matrix_C22, size/2, size/2);

        /*for(int i = 0; i < part; i++){
            for(int j = 0; j < part; j++){
                System.out.print(M1[i][j]+ " ");
            }
            System.out.println();
        }*/
        }
        return matrix_strassen_result;
    }

    public static void main(String[] args) {
        int[][] matrix_A;                           //To store the values for Matrix A
        int[][] matrix_B;                           //To store the values for Matrix B
        int[][] matrix_result;                      //To store the result of Standard Matrix Multiplication
        int[][] matrix_strassen_result;             //To store the result of the Strassen's Matrix Multiplication
        Dhillon_h_pa2_strassen m1 = new Dhillon_h_pa2_strassen();                   //Creating a object to call the functions
        int size=0;                                 //by default

        //Accepting input size of the matrix from command line
        if (args.length > 0) {                                  //Condition to check if we got any arguments or not
            try {
                size = Integer.parseInt(args[0]);               //Fetching the size from the arguments
                int count =0;
                for(int i = 0;i<10;i++){
                    if(size !=Math.pow(2,i)){                   //Condition to check if input is in the power of 2^i
                        count++;                                //Incrementing the counter
                    }
                }
                if(count>=10){                                  //if the counter value is > 10 that means the above condition failed completely
                    System.err.println("Invalid Size: Please pass the size of an array(n) where n=2^m");
                    System.exit(1);
                }
                if(size>1024){
                    System.err.println("Invalid Size: Value too large, please put n<=1024");
                    System.exit(1);
                }
            } catch (NumberFormatException e) {                 //Wasnt able to parse the data
                System.err.println("Invalid Arguments: Please pass the size of an array(n) where n=2^m");
                System.exit(1);
            }
        }else{                                                  //Condition will invoke if we dont pass any arguments
            System.err.println("No Arguments Passed: Please pass the size of an array(n) where n=2^m");
            System.exit(1);
        }
        //Accepting matrix A
        matrix_A = m1.accept_input(size);
        System.out.println("Matrix A is:");
        for(int i = 0; i < size; i++){
            for(int j = 0; j < size; j++){
                System.out.print(matrix_A[i][j]+ " ");
            }
            System.out.println();
        }

        //Accepting matrix B
        matrix_B = m1.accept_input(size);
        System.out.println("Matrix B is:");
        for(int i = 0; i < size; i++){
            for(int j = 0; j < size; j++){
                System.out.print(matrix_B[i][j]+ " ");
            }
            System.out.println();
        }

        //Calling the standard Matrix multiplication and printing the output
        matrix_result = m1.matrix_multiplication(size,matrix_A,matrix_B);
        System.out.println("The Standard Matrix Multiplication A*B is:");
        for(int i = 0; i < size; i++){
            for(int j = 0; j < size; j++){
                System.out.print(matrix_result[i][j]+ " ");
            }
            System.out.println();
        }

        //Calling the Strassen's Matrix multiplication function and printing the output
        matrix_strassen_result = m1.strassen_multiplication(matrix_A,matrix_B);
        System.out.println("The Strassen's Matrix Multiplication A*B is:");
        for(int i = 0; i < size; i++){
            for(int j = 0; j < size; j++){
                System.out.print(matrix_strassen_result[i][j]+ " ");
            }
            System.out.println();
        }
    }
}