import java.util.Arrays;
import java.math.BigInteger;
import java.util.Random;

class Dhillon_h_pa2_lim {

    //Declaring all the required functions early

    //Calculating Max of the two number lengths
    public int calculcateMaximum(int[] a, int[] b){
        int max = 0;
        if(a.length>=b.length) {
                max = a.length;
        }
        else{
                max = b.length;
        }
        return max;
    }

    //To calculate the product of two numbers which will be triggered on threshold
    public int[] calculateProduct(int[] numberA, int[] numberB) {
        int size1 = numberA.length;
        int size2 = numberB.length;
        int resultSize = size1 + size2;
        int[] result = new int[resultSize];

        // Perform the multiplication
        for (int i = size1 - 1; i >= 0; i--) {
            int carry = 0;
            for (int j = size2 - 1; j >= 0; j--) {
                int product = numberA[i] * numberB[j] + carry + result[i + j + 1];
                result[i + j + 1] = product % 10;
                carry = product / 10;
            }
            result[i] += carry;
        }
        int temp = 0;
        for(int i=0;i<result.length;i++){
            temp = ( temp*10 ) + result[i];
        }
        return (result);
    }

    public static int[] makePartition(int[] a, int start, int end){
        int[] part = new int[end-start];
        int j = 0;
        for(int i = start; i <end; i++){
            part[j] = a[i];
            j++;
            if(j==end){
                break;
            }
        }
        return part;
    }

    //ConvertArray function will convert the original array size to new array size based on the power
    public int[] convertArray(int[] a, int m){
        int newSize = a.length + m;                      //newSize will be the size of our new Array
        int[] temp = new int[newSize] ;                  //Creating a temp integer array of newSize
        for(int i = 0 ; i < a.length ; i++){
            temp[i] = a[i];                              //Initializing the temp array with the values of our array
        }
        for(int i = a.length ; i < newSize ; i++){
            temp[i] = 0;                                 //Appending the temp array with Zero's till new length
        }
        return (temp);                                   //Returning our new int array
    }

    //This function will remove the prefixZeros present in the arrays
    public int[] removePrefixZero(int[] num) {
        int i = 0;
        while (i < num.length && num[i] == 0) {
            i++;
        }
        if (i == num.length) {
            return new int[]{0}; // If the result is zero
        }
        return Arrays.copyOfRange(num, i, num.length);
    }

    //addIntegerArrays Function will reform the size of the integer arrays and add them
    public int[] addIntegerArrays(int[] numberA, int[] numberB) {
        int size1 = numberA.length;                               //Storing the size of numberA integer array
        int size2 = numberB.length;                               //Storing the size of numberB integer array
        int maxSize,carry = 0;                                    //Initializing our maxSize and carry as 0
        maxSize = calculcateMaximum(numberA,numberB);             //Calculating the maxSize
        int[] temp = new int[maxSize];                            //Creating a temp int array to reform our smaller array
        int[] sumResult = new int[maxSize + 1];                      //To store the resultant value, Adding 1 to cover for the carry integer bit

        //Reforming the array size
        if(size1 >= size2){
            int j = size1 - size2;                                //Storing the difference of the size of our 2 arrays
            /*Since the size of array numberB is smaller than numberA, So we need to reform our array numberB and make it equal
            to the size of array numberA. So adding
            */
            for (int i = 0; i < size2; i++) {
                temp[j] = numberB[i];
                j++;
            }
            numberB = temp;                                         //Reinitializing the variable

        }else{
            int j = size2 - size1;                                  //Storing the difference of the size of our 2 arrays
            /*Since the size of array numberA is smaller than numberB, So we need to reform our array numberA and make it equal
            to the size of array numberB. So adding
            */
            for (int i = 0; i < size1; i++) {
                temp[j] = numberA[i];
                j++;
            }
            numberA = temp;                                          //Reinitializing the variable
        }

        //Performing the add operation on integer arrays
        for (int i = maxSize - 1; i >= 0; i--) {                      //Adding from right to left i.e. going from the end of the array to the start
            int sum = numberA[i] + numberB[i] + carry;                //Initially carry will be 0
            sumResult[i + 1] = sum % 10;                              //Last bit of the sumResult array will be the addition of both the numbers and carry
            carry = sum / 10;                                         //Carry bit will be the remainder of the addition, so storing the value accordingly
        }
        sumResult[0] = carry;                                         //Our carry bit will come at the beginning of the array
        return (sumResult);
    }

    // Defining the Large Integer Multiplication for Two partitions using divide and conquer strategy
    public int[] largeIntegerMultiplicationTwo(int[] numberA, int[] numberB){
        int[] partA1,partA2,PartB1,partB2;
        int[] part, part1, part1_1, part2, part2_1, part3, part4, part5;
        int resultSize = numberA.length+numberB.length;
        int[] resultMultiplication = new int[resultSize];
        int maxSize = calculcateMaximum(numberA,numberB);

        //base condition
        /*if(a.length == 0 || b.length == 0){
            System.out.println("empty list");
            return result;
        }else*/ if(numberA.length <= 6 || numberB.length <=6){                                 //Threshold value
            part = calculateProduct(numberA,numberB);
            return removePrefixZero(part);
        }
        else{
            int m = (int)Math.ceil(maxSize/2);
            //System.out.println(m);

            //Making 2 partitions of numberA
            partA1 = makePartition(numberA,0,m);
            partA2 = makePartition(numberA,m,maxSize);

            //Making 2 partitions of numberB
            PartB1 = makePartition(numberB,0,m);
            partB2 = makePartition(numberB,m,maxSize);

            //Performing largeIntegerMultiplication on (A1,B1) and converting them with respect to their power maxSize = 2*m
            part1_1 =  largeIntegerMultiplicationTwo(partA1, PartB1);
            if(maxSize % 6 == 0){
                part1 = convertArray(part1_1,maxSize);                //Passing the maxSize as power to divide partitions as maxSize % 6 is 0 so equal partitions
            }
            else{
                part1 = convertArray(part1_1,maxSize+1);          //Passing maxSize+1 as power because the partition is even and odd as the maxSize % 6 !=0
            }

            //Performing recursive largeIntegerMultiplication for (A1,B2) and (B1,A2) and adding them
            part2_1 = addIntegerArrays(largeIntegerMultiplicationTwo(partA1, partB2), largeIntegerMultiplicationTwo(PartB1, partA2));

            //We need to convert this part2_1 with respect to power. Based on the maxSize value we will decide whether to give m or m+1 as a parameter
            if(maxSize % 2 != 1) {
                part2 = convertArray(part2_1, m);
            }else {
                part2 = convertArray(part2_1, m + 1);
            }
            part3 = addIntegerArrays(part1,part2);                      //Adding the part1 and part2 int arrays
            part4 = largeIntegerMultiplicationTwo(partA2,partB2);       //Performing largeIntegerMultiplication call on(A2,B2)
            part5 = addIntegerArrays(part3,part4);                      //Adding the above two operations performed i.e. part3 and part4
            resultMultiplication = removePrefixZero(part5);
            return resultMultiplication;
        }
    }

    // Defining the Large Integer Multiplication for Three partitions using divide and conquer strategy
    public int[] largeIntegerMultiplicationThree(int[] numberA, int[] numberB) {
        int sizeA = numberA.length;
        int sizeB = numberB.length;
        int[] partA1, partA2, partA3,z;
        int[] partB1, partB2, partB3;

        int[] part1, part2_1, part2_2, part2, part3, part4_1, part4_2, part4, part5_1, part5_2, part5, part6_1, part6_2, part6,part7,part8, part9,part10,z7,z8;
        int mA = (int)Math.ceil(sizeA/3);
        int mB = (int)Math.ceil(sizeB/3);

        //Checking if the partitions are a multiple of 3 or not, if not then adding 1 to the value of partitions
        if(sizeA != 3*mA){
            mA = mA+1;
        }
        if(sizeB != 3*mB){
            mB = mB+1;
        }

        //base condition
        /*if(a.length == 0 || b.length == 0){
            System.out.println("empty list");
            return result;
        }else*/ if (numberA.length < 6   || numberB.length < 6) {
            return (calculateProduct(numberA,numberB));
        }

            //Making 3 partitions of numberA
            partA1 = makePartition(numberA, 0, mA);
            partA2 = makePartition(numberA, mA, 2 * mA);
            partA3 = makePartition(numberA, 2 * mA, sizeA);

            //Making 3 partitions of numberB
            partB1 = makePartition(numberB, 0, mA);
            partB2 = makePartition(numberB, mA, 2 * mA);
            partB3 = makePartition(numberB, 2 * mA, sizeA);

            //Handling the case scenarios for which we have incremented the value of mA i.e. for not even partitions
            if (sizeA % mA != 0) {
                partA1 = convertArray(partA1, mA - partA1.length);
                partA2 = convertArray(partA2, mA - partA2.length);
                partA3 = convertArray(partA3, mA - partA3.length);
                partB1 = convertArray(partB1, mB - partB1.length);
                partB2 = convertArray(partB2, mB - partB2.length);
                partB3 = convertArray(partB3, mB - partB3.length);
            }

        int[] a,b,c,d,e,f;
        //int[] s1,s2,s3,s4,s5,s6;

        // Split the numbers into high and low parts


        a = makePartition(numberA,0,mA);//20
        b = makePartition(numberA,mA,2*mA);//00;
        c = makePartition(numberA,2*mA,sizeA);//07

        d = makePartition(numberB,0,mA);//10;
        e = makePartition(numberB,mA,2*mA);//34;;
        f = makePartition(numberB,2*mA,sizeA);//56;
        // System.out.println(n+"  "+m);
        if(sizeA % mA != 0){
            //System.out.println("Check:::");


            a = convertArray(a,mA-a.length);
            b = convertArray(b,mA-b.length);
            c = convertArray(c,mA-c.length);
            d = convertArray(d,mB-d.length);
            e = convertArray(e,mB-e.length);
            f = convertArray(f,mB-f.length);
        }


        //Handling the case scenarios for which we have incremented the value of mB i.e. for not even partitions


            //Performing calculations as per the formula:

            //Performing LargeIntegerMultiplication on (A3,B3)
            part1 = largeIntegerMultiplicationThree(partA3, partB3);

            //Performing LargeIntegerMultiplication on (A2,B3)
            part2_1 = largeIntegerMultiplicationThree(partA2, partB3);

            //Performing LargeIntegerMultiplication on (B2,A3)
            part2_2 = largeIntegerMultiplicationThree(partB2, partA3);

            //Adding both the sub parts of 2 i.e. part2_1 and part2_2
            part2 = addIntegerArrays(part2_1,part2_2);

            //Converting the result of part2 to the respect power by changing the size and adding 0's using the function convertArray
            part3 = convertArray(part2, mA);

            //Performing LargeIntegerMultiplication on (A3,B1)
            part4_1 = largeIntegerMultiplicationThree(partA3, partB1);

            //Performing LargeIntegerMultiplication on (A1,B3)
            part4_2 = largeIntegerMultiplicationThree(partA1, partB3);

            //Adding both the sub parts of 4 i.e. part4_1 and part4_2
            part4 = addIntegerArrays( part4_1,part4_2);

            //Performing LargeIntegerMultiplication on (A2,B2)
            part5_1 = largeIntegerMultiplicationThree(partA2, partB2);

            //Adding part4 with part5_1
            part5_2 = addIntegerArrays(part4,part5_1);

            //Converting the result of part2 to the respect power by changing the size and adding 0's using the function convertArray
            part5 = convertArray(part5_2, 2 * mA);

            //Performing LargeIntegerMultiplication on (A1,B2)
            part6_1 = largeIntegerMultiplicationThree(partA1, partB2);

            //Performing LargeIntegerMultiplication on (A2,B1)
            part6_2 = largeIntegerMultiplicationThree(partA2, partB1);

            //Adding both the parts of 6
            part6 = addIntegerArrays(part6_1,part6_2);

            //Converting the result of part2 to the respect power by changing the size and adding 0's using the function convertArray
            part7 = convertArray(part6, 3 * (mA));

            //Performing LargeIntegerMultiplication on (A1,B1)
            part8 =largeIntegerMultiplicationThree(partA1, partB1);

            //Converting the result of part2 to the respect power by changing the size and adding 0's using the function convertArray
            part9 = convertArray(part8, (4 * mA));

            //Adding all the parts
            part10 = addIntegerArrays(addIntegerArrays(addIntegerArrays(addIntegerArrays(part1, part3), part5), part7), part9);

        return removePrefixZero(part10);                //Removing the 0's present at the beginning
    }

    public int[] trimLeadingZeros1(int[] num){
        int[] temp = new int[num.length-1];
        int j = 1;
        for(int i =0;i<num.length;i++){
                temp[i]=num[i];
        }

        return temp;
    }

    public static void main(String[] args) {

        int size = 24;
        int[] resultPart2, resultPart3;
        Dhillon_h_pa2_lim lim = new Dhillon_h_pa2_lim();

        if (args.length > 0) {
            try {
                size = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                System.err.println("Failed to parse: Invalid Integer passed");
                System.exit(1);
            }
        } else {
            System.err.println("No Arguments passed: Please pass integer value");
            System.exit(1);
        }
        if (size % 6 != 0) {
            System.out.println("Invalid number");
        } else {

            //Generating Random Large Integers
            int[] a = new int[size];                                   //Large Integer number 1
            int[] b = new int[size];                                   //Large Integer number 2
            Random random = new Random();                           //Random Function to generate random integers
            for(int i = 0;i < size; i++){
                a[i] = (int)Math.floor(Math.random()*10);                   //Generating random integers from 0-9
                b[i] = (int)Math.floor(Math.random()*10);                   //Generating random integers from 0-9
            }

            //Printing the result for 2 part Large Integer Multiplication
            System.out.print("Large Integer Multiplication for Two parts is   : ");
            resultPart2 = lim.largeIntegerMultiplicationTwo(a,b);
            int newSize = resultPart2.length;
            for(int i = 0; i < newSize; i++){
                System.out.print(resultPart2[i]);
            }
            System.out.println();       //Line Separator

            //Printing the result for 3 part Large Integer Multiplication
            System.out.print("Large Integer Multiplication for Three parts is : ");
            resultPart3 = lim.largeIntegerMultiplicationThree(a,b);
            for(int i=0; i < newSize;i++){
                System.out.print(resultPart3[i]);
            }
            System.out.println();       //Line separator
        }
    }
}