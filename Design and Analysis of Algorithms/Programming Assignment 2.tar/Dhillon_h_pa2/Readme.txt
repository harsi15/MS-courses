javac Dhillon_h_pa2_strassen.java
java Dhillon_h_pa2_strassen (value)

specify a size of the matrix in the above line in place of (value) here value is in terms of n = 2^k

javac Dhillon_h_pa2_lim.java
java Dhillon_h_pa2_lim (value)

specify a size of the matrix in the above line in place of (value) here value is in terms of n =6m