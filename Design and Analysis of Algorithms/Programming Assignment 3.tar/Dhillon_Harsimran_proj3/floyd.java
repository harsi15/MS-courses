import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

public class floyd {

    //Writing the code algorithm to calculate path as mentioned in slide 48 of chapter 7
    public static String calculatePath ( int[][] path, int q, int r){

        //Using StringBuilder to store the values
        StringBuilder distancePath = new StringBuilder();

        if (path[q][r] != 0) {
            distancePath.append(" V").append(path[q][r]);
            distancePath.append(calculatePath(path, q, path[q][r] - 1));
            distancePath.append(calculatePath(path, path[q][r] - 1, r));
            return distancePath.toString();
        }

        //Will return empty String if the path[q][r] == 0
        return "";
    }

    public static void calculateShortestPath(int[][] inputMatrices) throws IOException {
        int x = inputMatrices.length;
        int[][] path = new int[x][x];                          //To store the path vertex
        int[][] distance = new int[x][x];                      //To store the distance value

        //Initializing a temp 2d array with the input matrix
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < x; j++) {
                distance[i][j] = inputMatrices[i][j];
            }
        }

        //Floyd's algorithm to check the min distance and calculate the shortest path
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < x; j++) {
                for (int k = 0; k < x; k++) {
                    if (k != i && k != j) {
                        if (distance[i][j] >= distance[i][k] + distance[k][j]) {
                            distance[i][j] = distance[i][k] + distance[k][j];
                            path[i][j] = k + 1;
                        }
                    }
                }
            }
        }

        //To print the path matrix
        /*for (int i = 0; i < x; i++) {
            for (int j = 0; j < x; j++) {
                System.out.print(path[i][j] + " ");
            }
            System.out.println();
        }*/

        for (int i = 0; i < x; i++) {
            //Creating string builder to save space while appending a string and storing the values
            StringBuilder shortestPath = new StringBuilder();

            //Creating the format of V(i+1)-Vj: shortest path and length, keeping i+1 because we are starting i from 0
            shortestPath.append("V").append(i + 1).append("-Vj: shortest path and length").append("\n");
            for (int j = 0; j < x; j++) {
                if (path[i][j] == 0) {
                    //Creating the format of (V(i+1) V(j+1) : distance)
                    shortestPath.append("V").append(i + 1).append(" V").append(j + 1).append(": ").append(distance[i][j]).append("\n");
                } else {
                    String temp = calculatePath(path, i, j);
                    shortestPath.append("V").append(i + 1).append(temp).append(" V").append(j + 1).append(": ").append(distance[i][j]).append("\n");
                }
            }
            shortestPath.append("\n");

            //Opening a file to write the shortest path of a problem in our output file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("Output.txt", true))) {
                //System.out.println(shortestPath);
                writer.write(shortestPath.toString());
            } catch (IOException e) {
                System.out.println("Failed to write inside a file"+e);
            }
        }
    }

        public static void main (String[]args) throws FileNotFoundException {
            /*int[][] inputMatrices = {
                    {0, 6, 5, 4, 6, 3, 6},
                    {6, 0, 6, 4, 5, 5, 3},
                    {5, 6, 0, 3, 1, 4, 6},
                    {4, 4, 3, 0, 4, 1, 4},
                    {6, 5, 1, 4, 0, 5, 5},
                    {3, 5, 4, 1, 5, 0, 3},
                    {6, 3, 6, 4, 5, 3, 0}
            };*/
        //File inputMatrixFile = new File("C:\\Users\\Personal\\IdeaProjects\\Dhillon_H_pa3\\src\\sampleInput.txt");

            int n =0;
            //Fetching file name from the command line argument
            if (args.length != 1) {
                System.out.println("Invalid parameters, Please enter a file name");
                System.exit(1);
            }
            //Storing the variables from the arguments
            String inputMatrixFileName = args[0];

            //Storing the path of the file name and giving it as an input to scanner object
            File inputMatrixFile = new File(inputMatrixFileName);
            Scanner sc = new Scanner(inputMatrixFile);

            try {
                while(sc.hasNext()){                        //To iterate till all the problems
                    while (sc.hasNextLine()) {              //To check for the first line of each problem to fetch values
                        StringBuilder inputMat = new StringBuilder();                           //Creating string builder to store values of the file
                        String s1 = sc.nextLine();                                              //Storing the first line as s1 to extract values
                        //Checking for the line which starts with P (Problem...)
                        if (s1.startsWith("P")) {
                            n = Integer.parseInt(s1.substring(14).trim());              //Fetching the value of n as it comes to be on the 14th index(found by checking each element)
                            inputMat.append(s1).append("\n").append("P matrix: ").append("\n");
                            //Opening the writer file to write inside the output file and keeping append as True
                            try (BufferedWriter writer = new BufferedWriter(new FileWriter("Output.txt", true))) {
                                writer.write(inputMat.toString());
                            } catch (IOException e) {
                                System.out.println("Failed to write in the output file");
                                e.printStackTrace();
                            }
                            break;
                        }
                    }

                    //Initializing our single problem matrix with the associated size
                    int[][] inputMatrix = new int[n][n];

                    //Putting the values in the matrix from the values present in file
                    for (int i = 0; i < n; i++) {
                        for (int j = 0; j < n; j++){
                            inputMatrix[i][j] = sc.nextInt();
                        }
                    }

                    //Calling function inside while loop so that it executes for all the problem statements inside the file
                    calculateShortestPath(inputMatrix);
                }
            }catch (IOException e) {
                throw new RuntimeException(e);
            } //End of catch block
        }  //End of main class
}   //End of floyd class