public class lcs {

    public static void calculateLcs(String s1, String s2){
        //Calculating the lengths of the string
        int sizeS1 = s1.length();
        int sizeS2 = s2.length();

        //Converting to array to perform operations
        char[] arr1 = s1.toCharArray();
        char[] arr2 = s2.toCharArray();

        //A resultantMatrix matrix to store the values
        int[][] resultantMatrix = new int[sizeS1+1][sizeS2+1];

        //Using StringBuilder to append the subsequence
        StringBuilder longestCommonSubs = new StringBuilder();

        //Initializing the first column to 0
        for(int i = 0; i < s1.length(); i++){
            resultantMatrix[i][0] = 0;
        }

        //Initializing the first row to 0
        for(int i = 0; i < s2.length(); i++){
            resultantMatrix[0][i] = 0;
        }

        //Creating the LCS matrix
        for(int i = 1; i <=s1.length(); i++){
            for(int j =1; j <=s2.length(); j++){
                //If both the elements are equal
                if (arr1[i-1] == arr2[j-1]) {
                    resultantMatrix[i][j] = resultantMatrix[i - 1][j - 1] + 1;
                    longestCommonSubs.append(arr1[i-1]);
                }else{
                    //Finding the max between [i-1][j] and [i][j-1]
                    if(resultantMatrix[i-1][j] >= resultantMatrix[i][j-1]){
                        resultantMatrix[i][j] = resultantMatrix[i-1][j];
                    }else{
                        resultantMatrix[i][j] = resultantMatrix[i][j-1];
                    }
                }
            }
        }
        //Printing the matrix
        /*for (int i = 0; i <= s1.length(); i++) {
            for (int j = 0; j <= s2.length(); j++) {
                System.out.print(resultantMatrix[i][j] + " ");
            }
            System.out.println();
        }*/
        System.out.println("Length of LCS: "+resultantMatrix[s1.length()][s2.length()]);
        System.out.println("LCS: "+longestCommonSubs);
    }

    public static void main(String[] args) {

        //Doing input validation, if arguments length is not 2 then it will exit
        if (args.length != 2) {
            System.out.println("Invalid arguments, Please enter 2 strings separated with a space");
            System.exit(1);
        }

        //Storing the variables from the arguments
        String s1 = args[0];
        String s2 = args[1];
        calculateLcs(s1,s2);
    }
}