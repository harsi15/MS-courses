To Run LCS
javac lcs.java
java lcs String1 String2

String1 = ABCDEfghi 
String2 = AcbDedghaq


To Run Floyd
javac floyd.java
java floyd sampleInput.txt