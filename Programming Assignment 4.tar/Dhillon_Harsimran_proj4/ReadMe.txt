Java Language

For createkn01 java file(createkn01.java)
javac createkn01.java
java createkn01 knapsack01.txt

For bruteforce java file(bruteforce.java)
javac bruteforce.java
java bruteforce knapsack01.txt

For Dynamic Programming Java file (dynpro.java)
javac dynpro.java
java dynpro knapsack01.txt

For IGreedy Programming Java file
javac igreedy.java
java igreedy knapsack01.txt