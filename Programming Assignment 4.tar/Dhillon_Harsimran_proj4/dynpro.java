import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

//Creating a class to use as a custom object to store different parameters
class Item3 {
    int profit;
    int weight;

    public String getItemIndex() {
        return itemIndex;
    }

    String itemIndex;

    Item3(String index,int profitValue, int weightValue){
        this.profit = profitValue;
        this.weight = weightValue;
        this.itemIndex = index;
    }
}
public class dynpro {


    public static String findMaxProfitDynamicProgramming(int totalItems, int totalWeight, List<Item1> itemList){

        //Initializing a n x m array where n will be totalItems +1 because we have 0th row and m will be totalWeight + 1 because we have 0th column
        int[][] dynoProfit = new int[totalItems + 1][totalWeight + 1];

        //Creating a outputList String Builder object to store the output in a desired format
        StringBuilder outputList = new StringBuilder();

        int maxProfit = 0;
        int weightUsed =0;

        List<Item3> selectedList = new ArrayList<>();

        //Setting the values of the first column of every row to 0
        for(int i = 0; i<totalItems + 1; i++){
            dynoProfit[i][0]=0;
        }

        //Setting the values of the first row of every column to 0
        for(int j = 0; j<totalWeight + 1; j++){
            dynoProfit[0][j]=0;
        }

        //Generating matrix of the profit and weight of each item
        for(int i=1; i<=totalItems; i++){
            for(int j=1; j<=totalWeight; j++){
                if(itemList.get(i-1).weight <= j){
                    dynoProfit[i][j] =Math.max(dynoProfit[i-1][j], itemList.get(i-1).profit + dynoProfit[i-1][j - itemList.get(i-1).weight]);
                }else{
                    dynoProfit[i][j] = dynoProfit[i-1][j];
                }
            }
        }

        //To check values of the array
        /*for(int i=0; i<totalItems +1; i++){
            for(int j=0; j<totalWeight +1; j++){
                System.out.print(dynoProfit[i][j]+" ");
            }
            System.out.println();
        }
        System.out.println();*/

        maxProfit = dynoProfit[totalItems][totalWeight];
        //System.out.println(maxProfit);

        int temp =maxProfit;
        //Iterating through the entire matrix in reverse order to find out which elements were included and which were not
        int i=totalItems;
        int j = totalWeight;
        while(i>0 && j>0){

                //Checking if the element on the (i)th row and (j)th column is present in the (i-1)th row and (j)th column
                if (temp == dynoProfit[i - 1][j]) {
                    //If the element is present decrement the value of i
                    i--;
                } else {
                    //For Elements not same
                    //Checking if the weight is less than the total weight of the knapsack and then only adding the elements to the selected list
                    weightUsed = weightUsed + itemList.get(i - 1).weight;
                    if(weightUsed < totalWeight){
                        //Initializing the item and adding the item to the list
                        Item3 item3 = new Item3(itemList.get(i - 1).itemIndex, itemList.get(i - 1).profit, itemList.get(i - 1).weight);
                        selectedList.add(item3);
                        //System.out.println("Profit is :" + temp);
                        //System.out.println("Item is " + item3.itemIndex);

                        //Decrementing the value of temp to get the profit subtraction of that element from the total profit
                        temp = temp - itemList.get(i - 1).profit;
                        //System.out.println(temp);
                        //Decrementing the value of j with the weight of that element
                        j = j - itemList.get(i-1).weight;
                    }
                    //If the weight exceeds the total bag limit, we will decrement the value of i
                    i--;
                }
            }

        //Sorting the list in ascending order of the itemIndex
        selectedList.sort(Comparator.comparing(Item3::getItemIndex));

        //To check the elements of the list
        /*for(i=0;i<selectedList.size();i++){
            System.out.println(selectedList.get(i).itemIndex+" "+selectedList.get(i).profit+" "+selectedList.get(i).weight);
        }*/

        //Storing the output in the required format
        outputList.append(selectedList.size()).append(" ").append(maxProfit).append(" ").append(weightUsed).append("\n");
        for(i=0;i<selectedList.size();i++){
            outputList.append(selectedList.get(i).itemIndex).append(" ").append(selectedList.get(i).profit).append(" ").append(selectedList.get(i).weight).append("\n");
        }

        return outputList.toString();
    }

    public static void main(String[] args) throws FileNotFoundException {

        //Initializing the filename variable to null;
        String filename ="";

        //Checking if we valid number of arguments are passed or not, if not then a custom error message will be displayed in the console
        if(args.length!=1){
            System.out.println("Invalid number of Arguments: Please provide a single filename from where the input has to be read");
            System.exit(1);
        }

        //fetching the filename from the argument
        filename = args[0];

        //Initializations
        File readFile = new File(filename);
        Scanner sc = new Scanner(readFile);
        StringBuilder inputListAndWeight = new StringBuilder();
        StringBuilder inputList = new StringBuilder();
        String outputList = "";

        //Iterating through the file to fetch the input
        while(sc.hasNext()){

            //To fetch the number of items and weight we will append the inputListAndWeight String with # so that it becomes easy to split the String
            if(sc.hasNextInt()){
                inputListAndWeight.append(sc.nextInt()).append("#");
            }
            else{
                //To fetch the items we will append the inputList String with # so that it becomes easy to split each item
                inputList.append(sc.nextLine()).append("#");
            }

        }

        //Using split function to get the required values and storing it in the variables
        String[] numberAndWeight = inputListAndWeight.toString().split("#");
        int totalItems = Integer.parseInt(numberAndWeight[0]);
        int totalWeight = Integer.parseInt(numberAndWeight[1]);
        //System.out.println(totalItems);
        //System.out.println(totalWeight);

        //Using split function to split each item and storing them in a list
        String[] inputItemList = inputList.toString().split("#");
        List<Item1> itemList = new ArrayList<>();
        for (int i = 1; i<=totalItems;i++){
            //System.out.println(itemList[i]);
            String[] itemSplit = inputItemList[i].split(" ");
            String itemName = itemSplit[0];
            int itemProfit = Integer.parseInt(itemSplit[1]);
            int itemWeight = Integer.parseInt(itemSplit[2]);
            Item1 item1 = new Item1(itemName,itemProfit,itemWeight);
            itemList.add(item1);
        }

        //To check the items of the list
        /*for(int i = 0; i< totalItems; i++){
            System.out.println(itemList.get(i).itemIndex+" "+itemList.get(i).profit+" "+itemList.get(i).weight);
        }*/

        //Getting the output as a string and storing it in outputList
        outputList = findMaxProfitDynamicProgramming(totalItems,totalWeight,itemList);

        //Using FileWriter to write in a file
        try{
            FileWriter fileWriter = new FileWriter("output2.txt");
            fileWriter.write(outputList);
            fileWriter.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
