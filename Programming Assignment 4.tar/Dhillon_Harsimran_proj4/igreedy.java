import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

//Creating a class to use as a custom object to store different parameters
class Item2 {
    int profit;
    int weight;

    float profitRatio;

    public float getProfitRatio() {
        return profitRatio;
    }

    String itemIndex;

    public String getItemIndex() {
        return itemIndex;
    }

    Item2(String index, int profitValue, int weightValue){
        this.profit = profitValue;
        this.weight = weightValue;
        this.itemIndex = index;
    }
}
public class igreedy {

    //Using this function to calculate the Max profit using improved greedy 4 approach
    public static String findMaxProfitIGreedy(int totalItems, int totalWeight, List<Item2> itemList){

        //Initializing variables
        int weight = 0;
        int profit = 0;
        int maxProfit = 0;
        List<Item2> selectedList = new ArrayList<>();
        StringBuilder outputList = new StringBuilder();

        //Calculating the Profit/Weight ratio and storing in the list
        for(int i =0; i<itemList.size();i++){
            itemList.get(i).profitRatio = (float) itemList.get(i).profit / itemList.get(i).weight;
        }

        //Sorting the profit/Weight ratio in non-ascending order to get the highest ratio at the beginning of the list
        itemList.sort(Comparator.comparingDouble(Item2::getProfitRatio).reversed());

        //To check the elements whether they are sorted or not
        /*for(int i=0;i<itemList.size();i++){
            System.out.println(itemList.get(i).itemIndex+" "+itemList.get(i).profit+" "+itemList.get(i).weight+" "+itemList.get(i).profitRatio);
        }*/

        //Iterating through all the elements
        for(int i =0;i<itemList.size();i++){
            weight = weight + itemList.get(i).weight;

            //Checking if the sum of weights of the items added to the knapsack is less than the capacity permitted
            if(weight <=totalWeight){

                //Initializing objects and storing them in a list
                Item2 item2 = new Item2(itemList.get(i).itemIndex,itemList.get(i).profit,itemList.get(i).weight);
                //System.out.println(item2.itemIndex);
                selectedList.add(item2);

                //Calculating profit and maxProfit
                profit = profit + itemList.get(i).profit;
                maxProfit = profit;

            }else{
                //if the weight of the item being added exceeds the limit, then removing that elements weight and choosing the next element
                weight = weight - itemList.get(i).weight;
            }
        }

        //Sorting the obtained list in the ascending order based on the item indices
        selectedList.sort(Comparator.comparing(Item2::getItemIndex));

        //To check if we have any element having greater profit as of the calculated profit (Advancement to greedy 4 Algorithm to get optimal solution)
        for(int i = 0; i< itemList.size();i++){
            if(itemList.get(i).weight<=totalWeight && itemList.get(i).profit > maxProfit){
                selectedList.clear();
                Item2 item2 = new Item2(itemList.get(i).itemIndex,itemList.get(i).profit,itemList.get(i).weight);
                selectedList.add(item2);
            }
        }

        //To check the items of the selected list
        /*for(int i=0;i<selectedList.size();i++){
            System.out.println(selectedList.get(i).itemIndex+" "+selectedList.get(i).profit+" "+selectedList.get(i).weight);
        }*/

        //Storing the output in required format
        outputList.append(selectedList.size()).append(" ").append(profit).append(" ").append(weight).append("\n");
        for(int i=0;i<selectedList.size();i++){
            outputList.append(selectedList.get(i).itemIndex).append(" ").append(selectedList.get(i).profit).append(" ").append(selectedList.get(i).weight).append("\n");
        }

        return outputList.toString();
    }


    public static void main(String[] args) throws FileNotFoundException {

        //Using the same code snippet to read and write in file as of bruteforce and createkn01 because the format is same
        //Initializing the filename variable to null;
        String filename ="";

        //Checking if we have arguments been passed or not, if not then a custom error message will be displayed in the console
        if(args.length!=1){
            System.out.println("Invalid Arguments: Please provide a filename from where the input has to be read");
            System.exit(1);
        }

        //Getting the filename from the argument
        filename = args[0];

        //Initializing the variables and Scanner object
        File readFile = new File(filename);
        Scanner sc = new Scanner(readFile);
        StringBuilder inputListAndWeight = new StringBuilder();
        StringBuilder inputList = new StringBuilder();
        String outputList = "";

        //Iterating through the file to fetch the required values
        while(sc.hasNext()){
            if(sc.hasNextInt()){
                //To fetch the Total items and weight
                inputListAndWeight.append(sc.nextInt()).append("#");
            }
            else{
                //To fetch the items of the list
                inputList.append(sc.nextLine()).append("#");
            }

        }

        //Extracting the values and storing them in variables
        String[] numberAndWeight = inputListAndWeight.toString().split("#");
        int totalItems = Integer.parseInt(numberAndWeight[0]);
        int totalWeight = Integer.parseInt(numberAndWeight[1]);

        //To check
        //System.out.println(totalItems);
        //System.out.println(totalWeight);

        //Fetching the items and storing them in a list
        String[] inputItemList = inputList.toString().split("#");
        List<Item2> itemList = new ArrayList<>();
        for (int i = 1; i<=totalItems;i++){
            //System.out.println(itemList[i]);
            String[] itemSplit = inputItemList[i].split(" ");
            String itemName = itemSplit[0];
            int itemProfit = Integer.parseInt(itemSplit[1]);
            int itemWeight = Integer.parseInt(itemSplit[2]);
            Item2 item2 = new Item2(itemName,itemProfit,itemWeight);
            itemList.add(item2);
        }

        //To print the values and check the items of the list
        /*for(int i = 0; i< totalItems; i++){
            System.out.println(itemList.get(i).itemIndex+" "+itemList.get(i).profit+" "+itemList.get(i).weight);
        }*/

        //Getting the output as a string and storing it in outputList
        outputList = findMaxProfitIGreedy(totalItems,totalWeight,itemList);

        //Using FileWriter to write in a file inside a try-catch block
        try{
            FileWriter fileWriter = new FileWriter("output3.txt");
            fileWriter.write(outputList);
            fileWriter.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
