import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

//Creating a class to use as a custom object to store different parameters
class Item {
    int profit;
    int weight;

    String itemIndex;

    Item(String index,int profitValue, int weightValue){
        this.profit = profitValue;
        this.weight = weightValue;
        this.itemIndex = index;
    }
}

public class createkn01{

    //Creating a function to generate random numbers having a bound i.e. with max and min values
    public int generateRandomNumbers(int min, int max){
        Random random = new Random();
        int randomValue = random.nextInt(max-min) +min;
        return randomValue;
    }

    public static void main(String[] args) throws IOException {

        //Initializing a filename variable
        String fileName = "";

        //Checking if we valid number of arguments are passed or not, if not then a custom error message will be displayed in the console
        if(args.length != 1){
            System.out.println("Invalid number of Arguments: Please provide a single filename where the output has to be written");
            System.exit(1);
        }

        //Fetching the file name from the argument
        fileName = args[0];

        //Initializing objects and variables
        createkn01 create01 = new createkn01();
        ArrayList<Item> itemList = new ArrayList<Item>();
        int maxWeights = 0;

        //Generating random numbers from a range of 5 to 10
        int totalItems = create01.generateRandomNumbers(5,10);
        //System.out.println(totalItems);

        //Generating random values of profit and weight from the given range and initializing the objects
        for(int i = 1; i <=totalItems; i++){
            int profit = create01.generateRandomNumbers(10,30);
            int weight = create01.generateRandomNumbers(5,20);
            Item item = new Item("Item"+i,profit,weight);

            itemList.add(item);                                             //Adding the initialized objects to a list
        }

        //Using for loop to calculate the maxWeight
        for(int i = 0;i<totalItems;i++){
            /*System.out.println(itemList.get(i).itemIndex);
            System.out.println(itemList.get(i).profit);
            System.out.println(itemList.get(i).weight);*/
            maxWeights = maxWeights + itemList.get(i).weight;

        }

        //Using the formula 0.6 x maxWeights to calculate the max capacity of knapsack
        maxWeights = (int) (Math.floor(0.6*maxWeights));

        //Creating a String Builder variable to store our output
        StringBuilder fileValue = new StringBuilder();

        //Appending the values as per the format required
        fileValue.append(totalItems).append(" ").append(maxWeights).append("\n");
        for(int i = 0;i<totalItems;i++){
            fileValue.append(itemList.get(i).itemIndex).append(" ").append(itemList.get(i).profit).append(" ").append(itemList.get(i).weight).append("\n");
        }

        //To check whether the format is correct or not
        //System.out.println(fileValue);

        //Using FileWriter to write in a file
        try {
            FileWriter fileWriter = new FileWriter(fileName);
            fileWriter.write(fileValue.toString());
            fileWriter.close();
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}