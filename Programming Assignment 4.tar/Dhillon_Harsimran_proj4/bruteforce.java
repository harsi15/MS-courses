import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//Creating a class to use as a custom object to store different parameters
class Item1 {
    int profit;
    int weight;

    String itemIndex;

    Item1(String index,int profitValue, int weightValue){
        this.profit = profitValue;
        this.weight = weightValue;
        this.itemIndex = index;
    }
}

public class bruteforce {

    //Using this function to calculate the items with max profit using Brute Force approach
    public static String findMaxProfit(int totalItems, int totalWeight, List<Item1> itemList){

        //Initializing Variables
        List<Item1> selectedList = new ArrayList<>();
        int maxProfit = 0;
        int binaryValue = 0;
        int weight = 0;
        int profit = 0;
        int weightUsed = 0;
        StringBuilder outputList = new StringBuilder();                 //String builder variable to store the format of our required output

        //Creating a binary representation to generate all possible combinations(Brute Force)
        int totalCombinations = (int)Math.pow(2,totalItems);
        String[] itemCombinations = new String[totalCombinations];              //The String array itemCombinations is used to store all the possible combinations

        //Iterating through the for loop to create the possible combinations
        for(int i = 0; i < totalCombinations; i++){
            itemCombinations[i] = Integer.toBinaryString(i);
            if(itemCombinations[i].length()<totalItems){
                int diff = totalItems - itemCombinations[i].length();
                for(int j = 0; j< diff;j++){
                    itemCombinations[i] = 0+itemCombinations[i];
                }
            }
            //System.out.println(itemCombinations[i]);
        }

        //Iterating through all the possible combinations
        for(int i = 0; i<totalCombinations;i++){
            //Resetting the variables to 0 for each iteration to discard earlier values
            weight =0;
            profit =0;
            ArrayList<Item1> tempSelectedList = new ArrayList<>();             //Creating a temp ArrayList to store the values of the items to compare and check through the loop

            //Iterating through all the items
            for(int j = 0;j<totalItems;j++){
                binaryValue = itemCombinations[i].charAt(j)-48;                 //subtracting with ASCII value to get binaryValue as 0's or 1's
                weight = weight + (itemList.get(j).weight*binaryValue);         //Adding the weight of the items to be stored in knapsack

                //Checking if the weight of items added is less than the allowed value of the knapsack
                if (weight <= totalWeight ) {
                    profit = profit + (itemList.get(j).profit)*binaryValue;     //Adding the profit value of the selected items
                    if(binaryValue==1) {
                        //Creating and initializing an object of item class with the item having binaryValue as 1 and storing it in the tempSelectedList
                        Item1 item2 = new Item1(itemList.get(j).itemIndex, itemList.get(j).profit, itemList.get(j).weight);
                        tempSelectedList.add(item2);
                    }
                }else{
                    //If the weight of the items exceeds the max allowed weight of the knapsack we will reset the values of the weight, profit and the tempSelectedList
                    weight =0;
                    profit = 0;
                    tempSelectedList.clear();
                }
            }

            //If the profit obtained is greater than the maxProfit and weight is also less than the allowed knapsack value then we would store the items selected
            if(profit>maxProfit && weight<=totalWeight){
                selectedList = tempSelectedList;
                maxProfit = profit;
                weightUsed = weight;
            }
        }

        //Printing the selected list of items
        /*for(int i=0;i<selectedList.size();i++){
            System.out.println(selectedList.get(i).itemIndex+" "+selectedList.get(i).profit+" "+selectedList.get(i).weight);
        }*/

        //Storing the output in the required format
        outputList.append(selectedList.size()).append(" ").append(maxProfit).append(" ").append(weightUsed).append("\n");
        for(int i=0;i<selectedList.size();i++){
            outputList.append(selectedList.get(i).itemIndex).append(" ").append(selectedList.get(i).profit).append(" ").append(selectedList.get(i).weight).append("\n");
        }

        //System.out.println(outputList);

        return outputList.toString();
    }

    public static void main(String[] args) throws FileNotFoundException {

        //Initializing the filename variable to null;
        String filename ="";

        //Checking if we valid number of arguments are passed or not, if not then a custom error message will be displayed in the console
        if(args.length!=1){
            System.out.println("Invalid number of Arguments: Please provide a single filename from where the input has to be read");
            System.exit(1);
        }

        //fetching the filename from the argument
        filename = args[0];

        //Initializations
        File readFile = new File(filename);
        Scanner sc = new Scanner(readFile);
        StringBuilder inputListAndWeight = new StringBuilder();
        StringBuilder inputList = new StringBuilder();
        String outputList = "";

        //Iterating through the file to fetch the input
        while(sc.hasNext()){

            //To fetch the number of items and weight we will append the inputListAndWeight String with # so that it becomes easy to split the String
            if(sc.hasNextInt()){
                inputListAndWeight.append(sc.nextInt()).append("#");
            }
            else{
                //To fetch the items we will append the inputList String with # so that it becomes easy to split each item
                inputList.append(sc.nextLine()).append("#");
            }

        }

        //Using split function to get the required values and storing it in the variables
        String[] numberAndWeight = inputListAndWeight.toString().split("#");
        int totalItems = Integer.parseInt(numberAndWeight[0]);
        int totalWeight = Integer.parseInt(numberAndWeight[1]);
        //System.out.println(totalItems);
        //System.out.println(totalWeight);

        //Using split function to split each item and storing them in a list
        String[] inputItemList = inputList.toString().split("#");
        List<Item1> itemList = new ArrayList<>();
        for (int i = 1; i<=totalItems;i++){
            //System.out.println(itemList[i]);
            String[] itemSplit = inputItemList[i].split(" ");
            String itemName = itemSplit[0];
            int itemProfit = Integer.parseInt(itemSplit[1]);
            int itemWeight = Integer.parseInt(itemSplit[2]);
            Item1 item1 = new Item1(itemName,itemProfit,itemWeight);
            itemList.add(item1);
        }

        //To check the items of the list
        /*for(int i = 0; i< totalItems; i++){
            System.out.println(itemList.get(i).itemIndex+" "+itemList.get(i).profit+" "+itemList.get(i).weight);
        }*/

        //Getting the output as a string and storing it in outputList
        outputList = findMaxProfit(totalItems,totalWeight,itemList);

        //Using FileWriter to write in a file
        try{
            FileWriter fileWriter = new FileWriter("output1.txt");
            fileWriter.write(outputList);
            fileWriter.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
